var fragmentShader = `
precision lowp float;
varying vec4 fColor;
varying vec4 fNormals;
varying float normalToCamera;
void main(){
	//gdy mamy dost�p do tablicy color
	gl_FragColor = vec4(fColor.rgb * 0.5 + fColor.rgb * normalToCamera, fColor.w);
//gdy nie mamy koloru, mo�na u�y� koloru szarego
		// gl_FragColor=vec4(0.5+normalToCamera/2.0, 0.5+normalToCamera/2.0, 0.5+normalToCamera/2.0, 1);
	}`
var old2fragmentShader = `
	precision lowp float;
	varying vec4 v_fColor;
	varying vec4 v_fNormals;
	varying float v_normalToCamera;
	void main(){
//gdy mamy dost�p do tablicy color
		//gl_FragColor=vec4(v_fColor.rgb*0.5 + v_fColor.rgb*v_normalToCamera, v_fColor.w);
//gdy nie mamy koloru, mo�na u�y� koloru szarego
		 gl_FragColor=vec4(0.5+v_normalToCamera/2.0, 0.5+v_normalToCamera/2.0, 0.5+v_normalToCamera/2.0, 1);
	}
`
var oldFragmentShader = `
varying lowp vec2 v_position;
void main() {
   gl_FragColor = vec4(v_position, sin(v_position.y * 4.0), 1);
}
`